from setuptools import setup, find_namespace_packages
setup(
    name = 'ilof_clean',
    version = '0.0.1',
    description = 'clean folder and translate file name',
    autor = 'Ilof Maks',
    autor_email = 'onischenkoalex94@gmail.com',
    packages = ['ilof_clean'],
    install_requires = [],
    python_requires = '>=3.5',
    include_package_data = True
)
